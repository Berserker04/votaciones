

<?php $__env->startSection('content'); ?>
    <div class="container-body">
        <div class="card shadow-lg p-3 mb-5 bg-body rounded" style="width: 40rem;">
            <div class="card-body">
                <h5 class="card-title">Resultados de las votaciones</h5>
                <table class="table table-dark table-striped">
                    <thead>
                        <tr>
                            <th># Candidato</th>
                            <th>Cantidad de votos</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $i = 1;
                        ?>
                        <?php $__currentLoopData = $votaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Candidato #<?php echo e($i++); ?></td>
                                <td><?php echo e($voto); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\afepa\OneDrive\Documentos\GitHub\votaciones\resources\views/admin.blade.php ENDPATH**/ ?>